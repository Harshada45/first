import Home from "./component/pages/Home";
import "./App.css";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  BrowserRouter,
} from "react-router-dom";
import "../node_modules/bootstrap/dist/css/bootstrap.css";
import About from "./component/pages/About";
import Contact from "./component/pages/Contact";
import NotFound from "./component/pages/NotFound";
import Navbar from "./component/layout/Navbar";
import AddUser from "./component/users/AddUser";
import EditUsers from "./component/users/EditUsers";
import View from "./component/users/View";

function App() {
  return (
    <>
      <BrowserRouter>
        <Navbar />
        <Switch>
          <Route exact path="/" component={Home} />
          <Route exact path="/about" component={About} />
          <Route exact path="/contact" component={Contact} />
          <Route exact path={"/users/add"} component={AddUser} />
          <Route exact path={"/users/edit/:id"} component={EditUsers} />
          <Route exact path={"/users/View/:id"} component={View} />

          <Route component={NotFound} />
        </Switch>
      </BrowserRouter>
    </>
  );
}

export default App;
