import axios from "axios";
import React, { useEffect, useState } from "react";
import { useHistory, useParams } from "react-router-dom";

function EditUsers() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    const result = await axios.get(`http://localhost:3001/student/${id}`);
    setUsers(result.data);
  };
  let history = useHistory();
  const { id } = useParams();

  const changeInput = (e) => {
    console.log(e.target.value);
    setUsers({ ...users, [e.target.name]: e.target.value });
  };

  const onSubmit = (e) => {
    e.preventDefault();
    axios.put(`http://localhost:3001/student/${id}`, users);
    history.push("/");
    alert("updated succesfully")
  };

  return (
    <>
      <div className="row">
        <div className="container">
          <div>
            <h2 className="text-center mt-3">Edit User</h2>
          </div>
          <div className="col-md-6 mx-auto mt-3 shadow p-3 mb-5 bg-white rounded p-4">
            <form onSubmit={(e) => onSubmit(e)}>
              <div className="form-group">
                <label>Enter Name</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter User Name"
                  name="name"
                  value={users.name}
                  onChange={(e) => changeInput(e)}
                />
              </div>
              <div className="form-group">
                <label>Enter Email Address</label>
                <input
                  type="text"
                  name="email"
                  value={users.email}
                  className="form-control"
                  placeholder="Enter Email Address"
                  onChange={(e) => changeInput(e)}
                />
              </div>
              <div className="form-group">
                <label>Enter Your Phone Number</label>
                <input
                  type="text"
                  name="phone"
                  value={users.phone}
                  className="form-control"
                  placeholder="Enter Phone Number"
                  onChange={(e) => changeInput(e)}
                />
              </div>
              <div className="form-group">
                <label>Enter Your Website</label>
                <input
                  type="text"
                  name="website"
                  value={users.website}
                  className="form-control"
                  placeholder="Enter Your Website"
                  onChange={(e) => changeInput(e)}
                />
              </div>

              <button className="btn btn-warning btn-block" >Update User</button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}
export default EditUsers;
