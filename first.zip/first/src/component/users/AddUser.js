import axios from "axios";
import React, { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";

function AddUser() {
  let history = useHistory();
  const [users, setUsers] = useState({
    name: "",
    email: "",
    phone: "",
    website: "",
  });

  const changeInput = (e) => {
    console.log(e.target.value);
    setUsers({ ...users, [e.target.name]: e.target.value });
  };

  const onSubmit = (e) => {
    e.preventDefault();
    axios.post("http://localhost:3001/student", users);
    history.push("/");
  };

  return (
    <>
      <div className="row">
        <div className="container">
          <div>
            <h2 className="text-center mt-3">Add User</h2>
          </div>
          <div className="col-md-6 mx-auto mt-5 shadow p-3 mb-5 bg-white rounded p-4">
            <form onSubmit={(e) => onSubmit(e)}>
              <div className="form-group">
                <label>Enter Name</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter User Name"
                  name="name"
                  value={users.name}
                  onChange={(e) => changeInput(e)}
                />
              </div>
              <div className="form-group">
                <label>Enter Email Address</label>
                <input
                  type="text"
                  name="email"
                  value={users.email}
                  className="form-control"
                  placeholder="Enter Email Address"
                  onChange={(e) => changeInput(e)}
                />
              </div>
              <div className="form-group">
                <label>Enter Your Phone Number</label>
                <input
                  type="text"
                  name="phone"
                  value={users.phone}
                  className="form-control"
                  placeholder="Enter Phone Number"
                  onChange={(e) => changeInput(e)}
                />
              </div>
              <div className="form-group">
                <label>Enter Your Website</label>
                <input
                  type="text"
                  name="website"
                  value={users.website}
                  className="form-control"
                  placeholder="Enter Your Website"
                  onChange={(e) => changeInput(e)}
                />
              </div>

              <button className="btn btn-primary btn-block">Add User</button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}
export default AddUser;
