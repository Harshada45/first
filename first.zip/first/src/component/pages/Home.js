import { Link, useParams } from "react-router-dom";
import axios from "axios";
import React, { useEffect, useState } from "react";
// import EditUsers from "./component/users/EditUsers";

const Home = () => {
  const [users, setUsers] = useState([]);
  const [user, setUser] = useState([]);
  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    const result = await axios.get("http://localhost:3001/student");
    console.log(result);
    setUsers(result.data.reverse([]));
  };

  const deleteUser = async (id) => {
    await axios.delete(`http://localhost:3001/student/${id}`);
    loadUsers();
    alert("deleted successfully");
  };

  const viewUser = async (id) => {
    const viewResult = await axios.get(`http://localhost:3001/student/${id}`);
    setUser(viewResult);
  };

  return (
    <>
      <div className="container">
        <table class="table table-bordered table-sm mt-5">
          <thead>
            <tr>
              <th>sr.no</th>
              <th>FirstName</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Website</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((item, index) => {
              return (
                <tr>
                  <td>{index + 1}</td>
                  <td>{item.name}</td>
                  <td>{item.email}</td>
                  <td>{item.phone}</td>
                  <td>{item.website}</td>
                  <td className="text-center ">
                    <Link
                      className="btn btn-primary mr-2"
                      to={`/users/view/${item.id}`}
                    >
                      view
                    </Link>
                    <Link
                      className="btn btn-outline-primary mr-2"
                      to={`/users/edit/${item.id}`}
                    >
                      Edit
                    </Link>
                    <Link
                      className="btn btn-danger"
                      onClick={() => deleteUser(item.id)}
                    >
                      {console.log(item.id)}
                      Delete
                    </Link>
                  </td>
                </tr>
              );
            })}
            {user.map((data, i) => {
              <p>{data}</p>;
            })}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default Home;
